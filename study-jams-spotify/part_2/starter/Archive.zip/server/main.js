import { Meteor } from 'meteor/meteor';

Meteor.methods({

    /* user functions
     'getUserInfo'(){
        var spotifyApi = new SpotifyWebApi();
        var response = spotifyApi.getMe();
        // if need to refresh token
        if (checkTokenRefreshed(response, spotifyApi)) {
          response = spotifyApi.getMe();
        }
        return response.data.body;
    },
    'getUsername'(){
        var spotifyApi = new SpotifyWebApi();
        var response = spotifyApi.getMe();
        // if need to refresh token
        if (checkTokenRefreshed(response, spotifyApi)) {
          response = spotifyApi.getMe();
        }
        return response.data.body.id;
    }, */
});

};
